
extern zend_class_entry *phalcon_cli_router_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Cli_Router_Exception);

